# Dataset Catalogue Seed Guide

The seed contains **737 records** across planning, ONS geography, HadUK-Grid partitions, Ordnance Survey, heritage, flood/terrain, energy, housing, property, transport, health, crime, Northern Ireland and Digimap collection metadata.

## Files
- `data/datasets_seed.csv` — easiest database seed input.
- `data/datasets_seed.json` — typed ingestion / frontend fixture.
- `data/DATASET_CATALOGUE.md` — human-readable index.

## Link semantics
- `direct_dataset`: dataset-level official page/API.
- `official_collection`: official page containing the named product/partition.
- `official_search_query`: authoritative portal search for the exact named dataset family; resolver must locate current item.
- `api_endpoint` / `api_documentation`: live structured service or its contract.
- `official_product_catalogue`: named product confirmed in official catalogue, direct product URL still to resolve.

## Verification semantics
Never publish all seeds as "verified". `partition_of_verified_dataset` means the parent product explicitly documents the partition convention. `indexed_family_from_official_portal` means the official portal taxonomy supports the family, but the ingestion worker must resolve the specific item ID and snapshot its metadata.

## Production ingestion
1. staging import;
2. canonical normalisation;
3. link resolver;
4. licence parser;
5. duplicate detection;
6. metadata validation;
7. source snapshot;
8. curator queue where uncertainty remains;
9. production publish.
