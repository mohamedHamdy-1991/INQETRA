# INQETRA — AI Build Pack

**INQETRA** is a research-design and dataset-intelligence platform that takes a researcher from a question to an executable, citable research data plan and a traceable abstract draft.

This directory is intentionally written so an autonomous coding agent can build the product with minimal product-design decisions.

## Start here
1. Read `00_START_HERE.md`.
2. Load `01_MASTER_BUILD_PROMPT.md` as the root coding-agent instruction.
3. Treat `data/datasets_seed.csv` as **seed metadata only**, not verified production truth.
4. Apply `design/inqetra_tokens.css` and `design/inqetra_components.css` globally before page implementation.
5. Use `prototype/landing.html` as the visual/interaction source for the landing page.

## Dataset seed
Current seed records: **737**. The catalogue deliberately mixes direct official records, official collection entries, official portal search records, and documented dataset partitions. Production ingestion must resolve/revalidate each record and preserve its verification state.

## Requested local destination
`/Users/mohamedali/Library/CloudStorage/OneDrive-LeedsBeckettUniversity/Work/GITHUB REPO/INQETRA`

This ChatGPT runtime cannot directly write into a local macOS OneDrive path. `scripts/install_to_target.sh` is included so the generated pack can be copied there on the Mac after download/extraction.
